// src/main/java/com/electronics_store/controller/ContactController.java
package com.electronics_store.controller;

import com.electronics_store.entities.ContactMessage;
import com.electronics_store.repository.ContactMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*") // frontend से CORS issue न आए
@RestController
@RequestMapping("/api/contact")
public class ContactController {

    @Autowired
    private ContactMessageRepository repo;

    @PostMapping
    public String saveContact(@RequestBody ContactMessage contact) {
        repo.save(contact);
        return "✅ Message saved successfully!";
    }
}
