package com.electronics_store.service.Impl;

import com.electronics_store.dto.UserDto;
import com.electronics_store.entities.User;
import com.electronics_store.repository.UserRepository;
import com.electronics_store.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDto registerUser(UserDto userDto) {
       User user = User.builder()
            .name(userDto.getName())
            .email(userDto.getEmail())
            .password(userDto.getPassword())
            .roles(userDto.getRole())
            .build();

        user = userRepository.save(user);

        return UserDto.builder()
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRoles())
                .build();
    }

    @Override
    public boolean validateUser(String email, String password) {
       User user = userRepository.findByEmail(email)
                .orElse(null);

        return user != null && user.getPassword().equals(password);
    }
}
