package com.electronics_store.service;

import com.electronics_store.dto.ProductDto;

import java.util.List;

public interface ProductService {
    List<ProductDto> getAllProducts();
    ProductDto getProductById(Long id);
    ProductDto createProduct(ProductDto dto);
    void deleteProduct(Long id);
}
