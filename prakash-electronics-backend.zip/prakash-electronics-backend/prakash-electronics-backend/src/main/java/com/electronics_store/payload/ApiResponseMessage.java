package com.electronics_store.payload;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponseMessage {
    private String message;
    private boolean success;
    private int status;
}
