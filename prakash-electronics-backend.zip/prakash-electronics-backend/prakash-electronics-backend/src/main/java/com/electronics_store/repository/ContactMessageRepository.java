// src/main/java/com/electronics_store/repository/ContactMessageRepository.java
package com.electronics_store.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.electronics_store.entities.ContactMessage;


public interface ContactMessageRepository extends JpaRepository<ContactMessage, Long> {
}
