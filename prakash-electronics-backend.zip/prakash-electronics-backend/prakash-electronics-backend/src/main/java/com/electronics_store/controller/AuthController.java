package com.electronics_store.controller;

import com.electronics_store.payload.ApiResponseMessage;
import com.electronics_store.payload.JwtResponse;
import com.electronics_store.payload.LoginRequest;
import com.electronics_store.payload.RegisterRequest;
import com.electronics_store.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponseMessage> register(@RequestBody RegisterRequest request) {
        try {
            String msg = authService.registerUser(request);
            return new ResponseEntity<>(new ApiResponseMessage(msg, true, HttpStatus.CREATED.value()), HttpStatus.CREATED);
        } catch (RuntimeException ex) {
            return new ResponseEntity<>(new ApiResponseMessage("Registration failed: " + ex.getMessage(), false, HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            JwtResponse jwt = authService.loginUser(request);
            return ResponseEntity.ok(jwt);
        } catch (RuntimeException ex) {
            return new ResponseEntity<>(new ApiResponseMessage("Invalid credentials", false, HttpStatus.UNAUTHORIZED.value()), HttpStatus.UNAUTHORIZED);
        }
    }
}
