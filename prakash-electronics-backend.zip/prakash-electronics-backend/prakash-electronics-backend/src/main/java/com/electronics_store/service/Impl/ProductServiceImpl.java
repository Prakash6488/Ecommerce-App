
package com.electronics_store.service.Impl;
import com.electronics_store.dto.ProductDto;
import com.electronics_store.entities.Product;
import com.electronics_store.mapper.ProductMapper;
import com.electronics_store.repository.ProductRepository;
import com.electronics_store.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository repo;

    @Override
    public List<ProductDto> getAllProducts() {
        return repo.findAll()
            .stream()
            .map(ProductMapper::toDto)
            .collect(Collectors.toList());
    }

    @Override
    public ProductDto getProductById(Long id) {
        Product product = repo.findById(id).orElseThrow();
        return ProductMapper.toDto(product);
    }

    @Override
    public ProductDto createProduct(ProductDto dto) {
        Product saved = repo.save(ProductMapper.toEntity(dto));
        return ProductMapper.toDto(saved);
    }

    @Override
    public void deleteProduct(Long id) {
        repo.deleteById(id);
    }
}
