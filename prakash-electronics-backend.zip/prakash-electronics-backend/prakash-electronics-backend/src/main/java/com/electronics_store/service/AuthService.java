package com.electronics_store.service;

import com.electronics_store.entities.User;
import com.electronics_store.payload.LoginRequest;
import com.electronics_store.payload.RegisterRequest;
import com.electronics_store.payload.JwtResponse;
import com.electronics_store.repository.UserRepository;
import com.electronics_store.config.JwtProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;

    // ✅ Register a new user
    public String registerUser(RegisterRequest request) {
        // Check if user already exists
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists!");
        }

        // Create and save new user
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .roles("ROLE_USER")
                .build();

        userRepository.save(user);

        return "User registered successfully!";
    }

    // ✅ Login user and generate JWT token
    public JwtResponse loginUser(LoginRequest request) {
        // Find user by email
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Verify password
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        // Generate JWT token
        String token = jwtProvider.generateToken(user.getEmail());

        return new JwtResponse(token);
    }
}
