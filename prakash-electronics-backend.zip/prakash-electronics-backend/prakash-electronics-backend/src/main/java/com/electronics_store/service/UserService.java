package com.electronics_store.service;

import com.electronics_store.dto.UserDto;

public interface UserService {
    UserDto registerUser(UserDto userDto);
    boolean validateUser(String email, String password);
}
