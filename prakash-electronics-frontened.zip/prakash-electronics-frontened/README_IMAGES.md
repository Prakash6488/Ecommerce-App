# Image Setup for Prakash Electronics

## Overview
This project uses a smart image system that handles product images exclusively from local files in `src/assets/` (no external placeholders).

## Image System

### Current Setup
- **Local Images Only**: Products use actual image files in `src/assets/`
- **Unique Images**: Each configured product is mapped to a specific local image

### Image Utility (`src/utils/imageUtils.js`)
The `getProductImage()` function:
1. Resolves the image via local mappings in `src/utils/productImages.js` using the product’s `name`
2. If no name-based image exists, falls back to a local category image
3. If both are missing, uses a local default image imported from `src/assets/`

## Products & Images
✅ All products in `src/data/products.js` are backed by local images via `src/utils/productImages.js`
✅ All products are displayed with images from local assets (no placeholders)

## Categories
The project includes products from these categories:
- Mobiles 📱
- Laptops 💻
- TVs 📺
- Headphones 🎧
- Accessories 🔌
- Cameras 📷
- Smartwatches ⌚
- Speakers 🔊
- Printers 🖨️
- Kitchen Appliances 🍳
- Fashion 👕
- Home & Furniture 🛋️
- Beauty & Personal Care 💄
- Sports & Fitness 🏃
- Books & Media 📚
- Toys & Games 🎮
- Automotive 🚗
- Grocery & Gourmet 🛒
- Health & Personal Care 🏥
- Pet Supplies 🐕
- Baby Care 👶
- Garden & Outdoor 🌱
- Electronics ⚡

## Adding Real Images (Optional)
To replace placeholder images with real product images:

1. Download product images
2. Save them in `src/assets/` folder
3. Name them according to the product (e.g., `product-1.jpg`, `product-2.jpg`)
4. Import them in `src/data/products.js`
5. The image utility will automatically use the local images

## Current Status
- ✅ 44 local images available in `src/assets/`
- ✅ 200 products total configured
- ✅ All products display images (local or placeholder)
- ✅ Image system works across all pages (Home, Catalog, Product Detail, Cart, Checkout, Orders)
