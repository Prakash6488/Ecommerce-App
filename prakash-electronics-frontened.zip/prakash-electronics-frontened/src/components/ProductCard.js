import React from "react";
import { useNavigate } from "react-router-dom";

import { getProductImage, getCategoryFallbackImage } from "../utils/imageUtils";

const ProductCard = ({ product }) => {
  const navigate = useNavigate();

  const productImage = getProductImage(product);

  const handleCardClick = () => {
    if (!product?.id) return;
    navigate(`/product/${product.id}`);
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      handleCardClick();
    }
  };

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={handleCardClick}
      onKeyDown={handleKeyDown}
      className="bg-white rounded-xl shadow-md hover:shadow-lg transition p-4 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
    >
      <img
        src={productImage}
        alt={product.name}
        className="w-full h-48 object-cover rounded-md mb-4"
        onError={(event) => {
          event.currentTarget.src = getCategoryFallbackImage(product);
        }}
      />
      <h3 className="text-lg font-semibold text-gray-800 line-clamp-2">
        {product.name}
      </h3>
      {product.brand && (
        <p className="text-gray-600 text-sm mt-1">{product.brand}</p>
      )}
      {product.price && (
        <p className="text-indigo-600 font-bold mt-2">
          ₹{product.price.toLocaleString()}
        </p>
      )}
      {product.rating && (
        <div className="mt-2 flex items-center gap-1 text-xs text-gray-500">
          <span className="text-yellow-400">
            {"★".repeat(Math.round(product.rating))}
          </span>
          <span>{product.rating}</span>
          {product.reviews && <span>({product.reviews} reviews)</span>}
        </div>
      )}
    </div>
  );
};

export default ProductCard;
