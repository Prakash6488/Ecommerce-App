// src/components/BottomNav.js
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, ShoppingCart, CreditCard } from 'lucide-react';

const BottomNav = () => {
  const location = useLocation();

  // Agar home, cart, ya checkout pe nahi ho, tab hi BottomNav dikhana (optional)
  if (!['/', '/cart', '/checkout'].includes(location.pathname)) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white shadow-md flex justify-around items-center py-2 z-50 md:hidden">
      <Link to="/" className="flex flex-col items-center text-gray-600">
        <Home size={20} />
        <span className="text-xs">Home</span>
      </Link>
      <Link to="/cart" className="flex flex-col items-center text-gray-600">
        <ShoppingCart size={20} />
        <span className="text-xs">Cart</span>
      </Link>
      <Link to="/checkout" className="flex flex-col items-center text-gray-600">
        <CreditCard size={20} />
        <span className="text-xs">Checkout</span>
      </Link>
    </div>
  );
};

export default BottomNav;
