import React, { createContext, useContext, useReducer, useEffect } from 'react';

const CartContext = createContext();

// Load cart from localStorage on initialization
const loadCartFromStorage = () => {
  try {
    const savedCart = localStorage.getItem('cart');
    return savedCart ? JSON.parse(savedCart) : [];
  } catch (error) {
    console.error('Error loading cart from localStorage:', error);
    return [];
  }
};

const initialState = {
  cart: loadCartFromStorage(),
  buyNowItem: null, // For "Buy Now" flow
};

const reducer = (state, action) => {
  let newState;
  
  switch (action.type) {
    case 'ADD_TO_CART':
      // Check if product already exists in cart
      const existingItem = state.cart.find(item => item.id === action.payload.id);
      if (existingItem) {
        // Product already in cart, don't add duplicate
        return state;
      }
      newState = { ...state, cart: [...state.cart, action.payload] };
      break;
    case 'REMOVE_FROM_CART':
      newState = { ...state, cart: state.cart.filter((item) => item.id !== action.payload) };
      break;
    case 'CLEAR_CART':
      newState = { ...state, cart: [], buyNowItem: null };
      break;
    case 'SET_BUY_NOW':
      newState = { ...state, buyNowItem: action.payload };
      break;
    case 'CLEAR_BUY_NOW':
      newState = { ...state, buyNowItem: null };
      break;
    default:
      return state;
  }
  
  // Save cart to localStorage whenever it changes (except for buyNowItem actions)
  if (newState && (action.type === 'ADD_TO_CART' || action.type === 'REMOVE_FROM_CART' || action.type === 'CLEAR_CART')) {
    try {
      localStorage.setItem('cart', JSON.stringify(newState.cart));
    } catch (error) {
      console.error('Error saving cart to localStorage:', error);
    }
  }
  
  return newState;
};

export const CartProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  return <CartContext.Provider value={{ state, dispatch }}>{children}</CartContext.Provider>;
};

export const useCart = () => useContext(CartContext);
