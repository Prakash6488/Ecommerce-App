// src/utils/productImages.js
// Centralized mapping of product and category images to local assets

import appleWatch from "../assets/appleWatch.jpg";
import asusVivobook from "../assets/asusVivobook.jpg";
import bajajToaster from "../assets/bajajToaster.jpg";
import boatAirdopes from "../assets/boatAirdopes.jpg";
import boatStone from "../assets/boatStone.jpg";
import boatXtend from "../assets/boatXtend.jpg";
import brotherPrinter from "../assets/brotherPrinter.jpg";
import canonEos from "../assets/canonEos.jpg";
import canonPixma from "../assets/canonPixma.jpg";
import dellInspiron from "../assets/dellInspiron.jpg";
import epsonEcoTank from "../assets/epsonEcoTank.jpg";
import fireBoltt from "../assets/fireboltt.jpg";
import flowervellyKurta from "../assets/Flowervelly Womens One Piece Kurta Set.jpg";
import fujifilmX from "../assets/fujifilmX.jpg";
import galaxyS23 from "../assets/galaxyS23.jpg";
import goproHero from "../assets/goproHero.jpg";
import hpPavilion from "../assets/hpPavilion.jpg";
import hpPrinter from "../assets/hpPrinter.jpg";
import iphone15 from "../assets/iphone15.jpg";
import jblBluetoothSpeaker from "../assets/jblSpeaker.jpg";
import jblTune from "../assets/jblTune.jpg";
import kentPurifier from "../assets/kentPurifier.jpg";
import lenovoIdeapad from "../assets/lenovoIdeapad.jpg";
import lgOled from "../assets/lgOled.jpg";
import logitechMouse from "../assets/logitechMouse.jpg";
import macbookAir from "../assets/macbookAir.jpg";
import mensCottonTshirt from "../assets/men's cotton t-shirt.jpg";
import mensDenimJeans from "../assets/Men's Denim Jeans.jpg";
import mensFormalShirt from "../assets/Men's Formal Shirt.jpg";
import mensSportsShoes from "../assets/Men's Sports Shoes.jpg";
import miPowerbank from "../assets/miPowerbank.jpg";
import miSpeaker from "../assets/miSpeaker.jpg";
import nikonD3500 from "../assets/nikonD3500.jpg";
import noiseColorfit from "../assets/noiseColorfit.jpg";
import oneplus11r from "../assets/oneplus11r.jpg";
import oneplusBullets from "../assets/oneplusBullets.jpg";
import oneplusTv from "../assets/oneplusTv.jpg";
import pantumPrinter from "../assets/pantumPrinter.jpg";
import philipsMixer from "../assets/philipsMixer.jpg";
import prestigeInduction from "../assets/prestigeInduction.jpg";
import realmeBuds from "../assets/realmeBuds.jpg";
import realmeNarzo from "../assets/realmeNarzo.jpg";
import redmiNote12 from "../assets/redmiNote12.jpg";
import samsungCharger from "../assets/samsungCharger.jpg";
import samsungTv from "../assets/samsungTv.jpg";
import samsungWatch from "../assets/samsungWatch.jpg";
import sonyAlpha from "../assets/sonyAlpha.jpg";
import sonyBravia from "../assets/sonyBravia.jpg";
import sonyHeadphones from "../assets/sonyHeadphones.jpg";
import sonySpeaker from "../assets/sonySpeaker.jpg";
import typeCAdapter from "../assets/typeCAdapter.jpg";
import usbCable from "../assets/usbCable.jpg";
import ushaFan from "../assets/ushaFan.jpg";
import xiaomiTv from "../assets/xiaomiTv.jpg";
import zebronicsSpeaker from "../assets/zebronicsSpeaker.jpg";
// Unused but available as a distinct Electronics fallback image
import electronicsCategoryFallback from "../assets/OnePlus 11R.jpg";

export const productImages = {
  "iPhone 15": iphone15,
  "Samsung Galaxy S23": galaxyS23,
  "Redmi Note 12": redmiNote12,
  "Realme Narzo": realmeNarzo,
  "OnePlus 11R": oneplus11r,
  "MacBook Air": macbookAir,
  "Dell Inspiron": dellInspiron,
  "HP Pavilion": hpPavilion,
  "Lenovo Ideapad": lenovoIdeapad,
  "ASUS Vivobook": asusVivobook,
  "Samsung Smart TV": samsungTv,
  "Sony Bravia": sonyBravia,
  "LG OLED TV": lgOled,
  "Xiaomi Smart TV": xiaomiTv,
  "OnePlus TV": oneplusTv,
  "Sony Headphones": sonyHeadphones,
  "boAt Airdopes": boatAirdopes,
  "JBL Tune": jblTune,
  "Realme Buds": realmeBuds,
  "OnePlus Bullets": oneplusBullets,
  "boAt Stone Speaker": boatStone,
  "JBL Bluetooth Speaker": jblBluetoothSpeaker,
  "Mi Portable Speaker": miSpeaker,
  "Zebronics Speaker": zebronicsSpeaker,
  "Sony Party Speaker": sonySpeaker,
  "Logitech Mouse": logitechMouse,
  "Apple Watch": appleWatch,
  "boAt Xtend Smartwatch": boatXtend,
  "Fire-Boltt Smartwatch": fireBoltt,
  "Noise Colorfit": noiseColorfit,
  "Samsung Galaxy Watch": samsungWatch,
  "HP DeskJet Printer": hpPrinter,
  "Canon Pixma Printer": canonPixma,
  "Epson EcoTank Printer": epsonEcoTank,
  "Pantum Laser Printer": pantumPrinter,
  "Brother Printer": brotherPrinter,
  "Canon EOS Camera": canonEos,
  "Nikon D3500 Camera": nikonD3500,
  "Fujifilm X Series": fujifilmX,
  "Sony Alpha Camera": sonyAlpha,
  "GoPro Hero": goproHero,
  "Mi Powerbank": miPowerbank,
  "Samsung 25W Charger": samsungCharger,
  "Type-C Adapter": typeCAdapter,
  "USB Cable": usbCable,
  "Philips Mixer": philipsMixer,
  "Prestige Induction Cooktop": prestigeInduction,
  "Bajaj Toaster": bajajToaster,
  "Kent Water Purifier": kentPurifier,
  "Usha Pedestal Fan": ushaFan,
  "Men's Cotton T-Shirt": mensCottonTshirt,
  "Men's Denim Jeans": mensDenimJeans,
  "Men's Formal Shirt": mensFormalShirt,
  "Men's Sports Shoes": mensSportsShoes,
  "Flowervelly Women's Kurta Set": flowervellyKurta,
};

export const categoryImages = {
  // Use a dedicated Electronics fallback image so that
  // products whose specific image fails (e.g. invalid file)
  // do NOT fall back to the iPhone 15 image.
  Electronics: electronicsCategoryFallback,
  Fashion: mensCottonTshirt,
  "Home & Kitchen": philipsMixer,
  Accessories: logitechMouse,
};

export const defaultProductImage = iphone15;

export const getProductImageByName = (name) => productImages[name] || null;

export const getCategoryImageByName = (category) =>
  categoryImages[category] || null;

