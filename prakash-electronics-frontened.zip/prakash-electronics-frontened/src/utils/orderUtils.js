// src/utils/orderUtils.js
// Helpers for dynamic order status, timeline stages and payment state.

export const ORDER_TIMELINE_STAGES = [
  "Ordered",
  "Shipped",
  "Out for delivery",
  "Delivered",
];

// Map arbitrary backend / stored status strings into one of our 4 stages.
const mapRawStatusToStage = (rawStatus) => {
  if (!rawStatus) return null;
  const s = String(rawStatus).toLowerCase();

  if (s.includes("deliver") && !s.includes("out")) {
    return "Delivered";
  }
  if (s.includes("out") && s.includes("deliver")) {
    return "Out for delivery";
  }
  if (s.includes("ship")) {
    return "Shipped";
  }
  if (s.includes("order") || s.includes("placed") || s.includes("confirm")) {
    return "Ordered";
  }

  return null;
};

// Derive dynamic order status based on explicit status or orderDate vs today.
export const getDynamicOrderStatus = (order) => {
  if (!order) return "Ordered";

  // Prefer mapped explicit status if present
  const explicit = mapRawStatusToStage(order.status);
  if (explicit) return explicit;

  // Fallback: derive from orderDate and today's date
  if (order.orderDate) {
    const placedAt = new Date(order.orderDate);
    if (!Number.isNaN(placedAt.getTime())) {
      const now = new Date();
      const diffMs = now - placedAt;
      const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));

      if (days <= 0) return "Ordered";
      if (days === 1) return "Shipped";
      if (days === 2) return "Out for delivery";
      return "Delivered";
    }
  }

  return "Ordered";
};

export const getTimelineStageIndex = (order) => {
  const status = getDynamicOrderStatus(order);
  const idx = ORDER_TIMELINE_STAGES.indexOf(status);
  return idx >= 0 ? idx : 0;
};

export const getPaymentMethodLabel = (method) => {
  switch (method) {
    case "card":
      return "Credit/Debit Card";
    case "upi":
      return "UPI";
    case "netbanking":
      return "NetBanking";
    case "cod":
    case "cash_on_delivery":
      return "Cash on Delivery (COD)";
    case "razorpay":
      return "Razorpay";
    default:
      return method || "Unknown";
  }
};

export const getPaymentMethodIcon = (method) => {
  switch (method) {
    case "card":
      return "💳";
    case "upi":
      return "📱";
    case "netbanking":
      return "🏦";
    case "cod":
    case "cash_on_delivery":
      return "💰";
    case "razorpay":
      return "🔐";
    default:
      return "💳";
  }
};

// Normalize payment status to one of: "Paid", "Pending", "Failed"
export const getPaymentStatus = (order) => {
  if (!order) return "Pending";

  const rawStatus =
    (order.paymentStatus ||
      order.payment_state ||
      order.payment_status ||
      "").toString().toLowerCase();

  let normalized = null;

  if (rawStatus) {
    if (
      ["paid", "success", "succeeded", "completed"].some((k) =>
        rawStatus.includes(k)
      )
    ) {
      normalized = "Paid";
    } else if (
      ["pending", "processing", "created"].some((k) =>
        rawStatus.includes(k)
      )
    ) {
      normalized = "Pending";
    } else if (
      ["fail", "cancel", "declin", "error"].some((k) =>
        rawStatus.includes(k)
      )
    ) {
      normalized = "Failed";
    }
  }

  if (!normalized) {
    const status = getDynamicOrderStatus(order);
    const method = (order.paymentMethod || "").toLowerCase();

    if (method === "cod" || method === "cash_on_delivery") {
      // COD is considered paid only after delivery
      normalized = status === "Delivered" ? "Paid" : "Pending";
    } else if (order.transactionId) {
      normalized = "Paid";
    } else if (status === "Delivered") {
      normalized = "Paid";
    } else {
      normalized = "Pending";
    }
  }

  return normalized;
};

