import {
  defaultProductImage,
  getCategoryImageByName,
  getProductImageByName,
} from "./productImages";

// Utility to get product images exclusively from local assets
// Always resolves via local mappings (product name/category),
// never from arbitrary URLs stored on the product object.
export const getProductImage = (product, fallbackImage = null) => {
  if (!product) {
    return fallbackImage || defaultProductImage;
  }

  // Resolve strictly from our local image maps
  const mappedImage = product.name
    ? getProductImageByName(product.name)
    : null;
  if (mappedImage) {
    return mappedImage;
  }

  const categoryImage = product.category
    ? getCategoryImageByName(product.category)
    : null;

  return categoryImage || fallbackImage || defaultProductImage;
};

// Provide a local fallback based on category
export const getCategoryFallbackImage = (productOrCategory) => {
  const category =
    typeof productOrCategory === "string"
      ? productOrCategory
      : productOrCategory?.category;

  return getCategoryImageByName(category) || defaultProductImage;
};

export const getCategoryImage = (category) =>
  getCategoryImageByName(category) || defaultProductImage;
