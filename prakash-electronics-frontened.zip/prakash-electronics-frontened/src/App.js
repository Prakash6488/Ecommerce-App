// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import Category from './pages/Category';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import ProductDetail from './pages/ProductDetail';
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import ForgotPassword from './components/Auth/ForgotPassword';
import VerifyOTP from './components/Auth/VerifyOTP';
import ResetPassword from './components/Auth/ResetPassword';
import DeliveryAddress from './pages/DeliveryAddress';
import Dashboard from './pages/User/Dashboard';
import MyProfile from './pages/User/MyProfile';
import MyOrders from './pages/User/MyOrders';
import EditProfile from './pages/User/EditProfile';
import Contact from './pages/Contact';
import OrderConfirmation from './pages/OrderConfirmation';

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/catalog" element={<Catalog />} />
        <Route path="/category/:name" element={<Category />} />
        <Route path="/product/:id" element={<ProductDetail />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/order-confirmation" element={<OrderConfirmation />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/verify-otp" element={<VerifyOTP />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/delivery" element={<DeliveryAddress />} />
        <Route path="/contact" element={<Contact />} />
        
        {/* ✅ Dashboard Route Setup */}
        <Route path="/dashboard" element={<Dashboard />}>
          <Route path="profile" element={<MyProfile />} />
          <Route path="orders" element={<MyOrders />} />
          <Route path="edit" element={<EditProfile />} />
        </Route>

      </Routes>
    </Router>
  );
}

export default App;
