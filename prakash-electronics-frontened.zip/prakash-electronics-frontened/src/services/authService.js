// Local Authentication Service - Works without backend
// Falls back to localStorage if backend is unavailable

const DEMO_USERS = [
  {
    email: 'demo@example.com',
    password: 'demo123',
    fullName: 'Demo User',
    phone: '1234567890',
    address: '123 Demo Street',
    gender: 'MALE',
    dob: '1990-01-01',
    country: 'India',
    state: 'Delhi'
  },
  {
    email: 'prakashlal6488@gmail.com',
    password: 'password123',
    fullName: 'Prakash Lal',
    phone: '9876543210',
    address: 'Your Address',
    gender: 'MALE',
    dob: '1995-05-15',
    country: 'India',
    state: 'Delhi'
  }
];

// Initialize demo users in localStorage if not exists
const initializeDemoUsers = () => {
  const storedUsers = localStorage.getItem('localUsers');
  if (!storedUsers) {
    localStorage.setItem('localUsers', JSON.stringify(DEMO_USERS));
  }
};

// Get all users from localStorage
const getLocalUsers = () => {
  initializeDemoUsers();
  const users = localStorage.getItem('localUsers');
  return users ? JSON.parse(users) : DEMO_USERS;
};

// Save users to localStorage
const saveLocalUsers = (users) => {
  localStorage.setItem('localUsers', JSON.stringify(users));
};

// Generate a simple token
const generateToken = (email) => {
  return btoa(`${email}:${Date.now()}`).substring(0, 50);
};

// Local Authentication Functions
export const localAuth = {
  // Register a new user locally
  register: (userData) => {
    const users = getLocalUsers();
    
    // Check if user already exists
    if (users.find(u => u.email === userData.email)) {
      throw new Error('User with this email already exists');
    }

    // Add new user
    const newUser = {
      ...userData,
      password: userData.password // In real app, this would be hashed
    };
    
    users.push(newUser);
    saveLocalUsers(users);
    
    // Auto-login after registration
    const token = generateToken(userData.email);
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(newUser));
    
    return { token, user: newUser, message: 'Registration successful!' };
  },

  // Login locally
  login: (email, password) => {
    const users = getLocalUsers();
    const user = users.find(u => u.email === email && u.password === password);
    
    if (!user) {
      throw new Error('Invalid email or password');
    }

    const token = generateToken(email);
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    
    return { token, user, message: 'Login successful!' };
  },

  // Check if user is logged in
  isAuthenticated: () => {
    return !!localStorage.getItem('token');
  },

  // Get current user
  getCurrentUser: () => {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  },

  // Logout
  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
};

// Backend Authentication (with fallback)
export const authService = {
  // Try backend first, fallback to local
  login: async (email, password) => {
    const BACKEND_URL = 'http://localhost:8081/api/auth/login';
    
    try {
      // Try backend first
      const response = await fetch(BACKEND_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const data = await response.json();
        const token = data.token || data.jwt || data;
        
        if (token) {
          localStorage.setItem('token', token);
          return { token, message: 'Login successful!', source: 'backend' };
        }
      }
      
      // If backend fails, try local auth
      return localAuth.login(email, password);
    } catch (error) {
      // Backend unavailable, use local auth
      console.log('Backend unavailable, using local authentication');
      return localAuth.login(email, password);
    }
  },

  // Register with backend fallback
  register: async (userData) => {
    const BACKEND_URL = 'http://localhost:8081/api/auth/register';
    
    try {
      const response = await fetch(BACKEND_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      if (response.ok) {
        const data = await response.json();
        return { ...data, source: 'backend' };
      }
      
      // If backend fails, use local auth
      return localAuth.register(userData);
    } catch (error) {
      // Backend unavailable, use local auth
      console.log('Backend unavailable, using local authentication');
      return localAuth.register(userData);
    }
  },

  // Check authentication
  isAuthenticated: () => {
    return localAuth.isAuthenticated();
  },

  // Get current user
  getCurrentUser: () => {
    return localAuth.getCurrentUser();
  },

  // Logout
  logout: () => {
    localAuth.logout();
  }
};

// Initialize demo users on import
initializeDemoUsers();

