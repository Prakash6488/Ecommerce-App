// OTP Service for Password Reset
// In production, this would send actual emails via a service like SendGrid, AWS SES, etc.

// Store OTPs temporarily (in production, use Redis or database)
const otpStorage = {};

// Generate a 6-digit OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// OTP expires in 10 minutes
const OTP_EXPIRY = 10 * 60 * 1000; // 10 minutes in milliseconds

export const otpService = {
  // Send OTP to email (mock implementation)
  sendOTP: async (email) => {
    // Check if user exists in local storage
    const users = JSON.parse(localStorage.getItem('localUsers') || '[]');
    const user = users.find(u => u.email === email);
    
    if (!user) {
      throw new Error('No account found with this email address');
    }

    // Generate OTP
    const otp = generateOTP();
    const expiryTime = Date.now() + OTP_EXPIRY;

    // Store OTP with email
    otpStorage[email] = {
      otp,
      expiryTime,
      attempts: 0
    };

    // In production, send email here:
    // await emailService.sendOTPEmail(email, otp);

    // For demo purposes, we'll log it to console and show it in UI
    console.log(`OTP for ${email}: ${otp}`);
    
    // Store in localStorage for demo (in production, this would be server-side)
    localStorage.setItem(`otp_${email}`, JSON.stringify({
      otp,
      expiryTime,
      attempts: 0
    }));

    return {
      success: true,
      message: `OTP sent to ${email}`,
      // In demo mode, we'll return the OTP (remove this in production)
      demoOTP: process.env.NODE_ENV === 'development' ? otp : null
    };
  },

  // Verify OTP
  verifyOTP: (email, otp) => {
    const stored = localStorage.getItem(`otp_${email}`);
    
    if (!stored) {
      throw new Error('OTP not found. Please request a new OTP.');
    }

    const otpData = JSON.parse(stored);

    // Check if OTP expired
    if (Date.now() > otpData.expiryTime) {
      localStorage.removeItem(`otp_${email}`);
      throw new Error('OTP has expired. Please request a new one.');
    }

    // Check attempts (max 5 attempts)
    if (otpData.attempts >= 5) {
      localStorage.removeItem(`otp_${email}`);
      throw new Error('Too many failed attempts. Please request a new OTP.');
    }

    // Verify OTP
    if (otpData.otp !== otp) {
      otpData.attempts += 1;
      localStorage.setItem(`otp_${email}`, JSON.stringify(otpData));
      throw new Error(`Invalid OTP. ${5 - otpData.attempts} attempts remaining.`);
    }

    // OTP verified successfully
    // Mark email as verified for password reset
    localStorage.setItem(`otp_verified_${email}`, 'true');
    localStorage.removeItem(`otp_${email}`);

    return {
      success: true,
      message: 'OTP verified successfully'
    };
  },

  // Check if email is verified for password reset
  isEmailVerified: (email) => {
    return localStorage.getItem(`otp_verified_${email}`) === 'true';
  },

  // Reset password
  resetPassword: (email, newPassword) => {
    // Check if email is verified
    if (!otpService.isEmailVerified(email)) {
      throw new Error('Email not verified. Please complete OTP verification.');
    }

    // Get users from localStorage
    const users = JSON.parse(localStorage.getItem('localUsers') || '[]');
    const userIndex = users.findIndex(u => u.email === email);

    if (userIndex === -1) {
      throw new Error('User not found');
    }

    // Update password
    users[userIndex].password = newPassword;
    localStorage.setItem('localUsers', JSON.stringify(users));

    // Clear verification flag
    localStorage.removeItem(`otp_verified_${email}`);

    return {
      success: true,
      message: 'Password reset successfully'
    };
  },

  // Clear OTP data (for cleanup)
  clearOTP: (email) => {
    localStorage.removeItem(`otp_${email}`);
    localStorage.removeItem(`otp_verified_${email}`);
  }
};

