import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import products from "../data/products";
import { getProductImage, getCategoryFallbackImage } from "../utils/imageUtils";

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { state, dispatch } = useCart();

  const product = products.find((p) => p.id === parseInt(id, 10));

  if (!product) return <div>Product not found</div>;

  // Check if product is already in cart
  const isInCart = state.cart.some((item) => item.id === product.id);

  const handleAddToCart = () => {
    if (!isInCart) {
      dispatch({ type: "ADD_TO_CART", payload: product });
    } else {
      navigate("/cart");
    }
  };

  const handleBuyNow = () => {
    dispatch({ type: "SET_BUY_NOW", payload: product });
    navigate("/checkout");
  };

  // Derive simple specifications from existing product data
  const specifications = [
    { label: "Brand", value: product.brand || "—" },
    { label: "Category", value: product.category || "—" },
    {
      label: "Price",
      value: product.price ? `₹${product.price.toLocaleString()}` : "—",
    },
    {
      label: "Original Price",
      value:
        product.originalPrice && product.originalPrice > product.price
          ? `₹${product.originalPrice.toLocaleString()}`
          : "—",
    },
    {
      label: "Discount",
      value: product.discount ? `${product.discount}% OFF` : "—",
    },
    {
      label: "Customer Rating",
      value: product.rating
        ? `${product.rating} (${product.reviews || 0} reviews)`
        : "—",
    },
    {
      label: "Availability",
      value: product.inStock ? "In Stock" : "Out of Stock",
    },
  ];

  // Simple positive & negative review snippets like Flipkart
  const baseName = product.name;
  const brand = product.brand || "this product";

  const positiveReviews = [
    `Amazing performance from ${brand}! ${baseName} feels premium and delivers exactly as promised.`,
    `Value for money. Display and build quality of ${baseName} are excellent for the price.`,
  ];

  const negativeReviews = [
    `Good overall, but battery/usage could be better on ${baseName}.`,
    `Packaging and delivery were fine, but expected a bit more from ${brand} at this price point.`,
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Product Image */}
            <div className="flex justify-center items-start">
              <img
                src={getProductImage(product)}
                alt={product.name}
                className="w-full max-w-md h-auto object-contain rounded-lg"
                onError={(e) => {
                  e.target.src = getCategoryFallbackImage(product);
                }}
              />
            </div>

            {/* Product Details (primary info + price/actions) */}
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                {product.name}
              </h1>

              {product.brand && (
                <p className="text-lg text-gray-600 mb-4">
                  Brand: {product.brand}
                </p>
              )}

              {product.description && (
                <p className="text-gray-700 mb-6 leading-relaxed">
                  {product.description}
                </p>
              )}

              {/* Rating */}
              {product.rating && (
                <div className="flex items-center gap-2 mb-6">
                  <div className="flex text-yellow-400">
                    {"★".repeat(Math.floor(product.rating))}
                    {product.rating % 1 !== 0 && "☆"}
                    {"★".repeat(5 - Math.ceil(product.rating))}
                  </div>
                  <span className="text-gray-600">
                    {product.rating} ({product.reviews || 0} reviews)
                  </span>
                </div>
              )}

              {/* Price */}
              <div className="mb-6">
                <div className="flex items-center gap-4 mb-2">
                  <span className="text-4xl font-bold text-gray-900">
                    ₹{product.price?.toLocaleString()}
                  </span>
                  {product.originalPrice &&
                    product.originalPrice > product.price && (
                      <>
                        <span className="text-2xl text-gray-500 line-through">
                          ₹{product.originalPrice.toLocaleString()}
                        </span>
                        <span className="text-lg text-green-600 font-semibold">
                          Save ₹
                          {(
                            product.originalPrice - product.price
                          ).toLocaleString()}
                        </span>
                      </>
                    )}
                </div>
                {product.discount && (
                  <span className="inline-block bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {product.discount}% OFF
                  </span>
                )}
              </div>

              {/* Stock Status */}
              <div className="mb-8">
                {product.inStock ? (
                  <span className="text-green-600 font-semibold text-lg">
                    ✓ In Stock
                  </span>
                ) : (
                  <span className="text-red-600 font-semibold text-lg">
                    ✗ Out of Stock
                  </span>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={handleAddToCart}
                  disabled={!product.inStock}
                  className={`flex-1 py-3 px-6 rounded-lg text-lg font-semibold transition-all ${
                    product.inStock
                      ? isInCart
                        ? "bg-green-600 text-white hover:bg-green-700 hover:shadow-lg transform hover:scale-105"
                        : "bg-blue-600 text-white hover:bg-blue-700 hover:shadow-lg transform hover:scale-105"
                      : "bg-gray-300 text-gray-500 cursor-not-allowed"
                  }`}
                >
                  {product.inStock
                    ? isInCart
                      ? "Go to Cart"
                      : "Add to Cart"
                    : "Out of Stock"}
                </button>
                <button
                  onClick={handleBuyNow}
                  disabled={!product.inStock}
                  className={`flex-1 py-3 px-6 rounded-lg text-lg font-semibold transition-all ${
                    product.inStock
                      ? "bg-orange-500 text-white hover:bg-orange-600 hover:shadow-lg transform hover:scale-105"
                      : "bg-gray-300 text-gray-500 cursor-not-allowed"
                  }`}
                >
                  {product.inStock ? "Buy Now" : "Out of Stock"}
                </button>
              </div>

              {/* Category */}
              {product.category && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <p className="text-sm text-gray-600">
                    Category:{" "}
                    <span className="font-semibold text-gray-900">
                      {product.category}
                    </span>
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Specifications & Reviews (full detail like Flipkart) */}
          <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Specifications */}
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                Specifications
              </h2>
              <div className="border rounded-xl p-4 md:p-6 bg-gray-50">
                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-sm text-gray-700">
                  {specifications.map((spec) => (
                    <div key={spec.label} className="flex">
                      <dt className="w-32 font-medium text-gray-600">
                        {spec.label}
                      </dt>
                      <dd className="flex-1">{spec.value}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>

            {/* Customer Reviews */}
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                Customer Reviews
              </h2>
              <div className="space-y-4">
                {/* Positive reviews */}
                <div className="border rounded-xl p-4 bg-green-50 border-green-200">
                  <p className="text-sm font-semibold text-green-800 mb-1">
                    Positive
                  </p>
                  {positiveReviews.map((text, index) => (
                    <p key={index} className="text-sm text-gray-800 mb-1">
                      • {text}
                    </p>
                  ))}
                </div>

                {/* Negative / critical reviews */}
                <div className="border rounded-xl p-4 bg-red-50 border-red-200">
                  <p className="text-sm font-semibold text-red-800 mb-1">
                    Critical
                  </p>
                  {negativeReviews.map((text, index) => (
                    <p key={index} className="text-sm text-gray-800 mb-1">
                      • {text}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
