// src/pages/Cart.js

import React from 'react';
import { useCart } from '../context/CartContext';
import { useNavigate, Link } from 'react-router-dom';
import { getProductImage, getCategoryFallbackImage } from '../utils/imageUtils';

const Cart = () => {
  const { state, dispatch } = useCart();
  const navigate = useNavigate();

  const handleRemove = (id) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: id });
  };

  const handleCheckout = () => {
    navigate('/checkout');
  };

  const subtotal = state.cart.reduce((acc, item) => acc + (item.price || 0), 0);
  const deliveryCharge = subtotal > 500 ? 0 : 50;
  const totalPrice = subtotal + deliveryCharge;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl font-bold mb-8 text-gray-900">🛒 Your Cart</h2>

        {state.cart.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="text-6xl mb-4">🛒</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Your cart is empty</h3>
            <p className="text-gray-600 mb-6">Looks like you haven't added anything to your cart yet.</p>
            <Link 
              to="/"
              className="inline-block bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:shadow-lg transition-all transform hover:scale-105"
            >
              Continue Shopping
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {state.cart.map((item) => (
                <div 
                  key={item.id} 
                  className="bg-white rounded-xl shadow-md p-6 flex flex-col sm:flex-row items-center gap-4 hover:shadow-lg transition-shadow"
                >
                  <img 
                    src={getProductImage(item)} 
                    alt={item.name} 
                    className="w-32 h-32 object-cover rounded-lg border border-gray-200"
                    onError={(e) => {
                      e.target.src = getCategoryFallbackImage(item);
                    }}
                  />
                  <div className="flex-1 w-full sm:w-auto">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.name}</h3>
                    {item.brand && (
                      <p className="text-sm text-gray-500 mb-2">Brand: {item.brand}</p>
                    )}
                    <p className="text-2xl font-bold text-indigo-600">₹{item.price?.toLocaleString()}</p>
                  </div>
                  <button
                    onClick={() => handleRemove(item.id)}
                    className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-lg font-semibold transition-all transform hover:scale-105 shadow-md hover:shadow-lg"
                    title="Remove this item from cart"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-xl shadow-lg p-6 sticky top-4">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Order Summary</h3>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-gray-700">
                    <span>Subtotal ({state.cart.length} {state.cart.length === 1 ? 'item' : 'items'}):</span>
                    <span className="font-semibold">₹{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-gray-700">
                    <span>Delivery:</span>
                    <span className="font-semibold">{deliveryCharge === 0 ? 'Free' : `₹${deliveryCharge}`}</span>
                  </div>
                  {subtotal < 500 && (
                    <p className="text-sm text-green-600">
                      Add ₹{(500 - subtotal).toLocaleString()} more for free delivery!
                    </p>
                  )}
                  <div className="border-t pt-4 flex justify-between text-xl font-bold text-gray-900">
                    <span>Total:</span>
                    <span>₹{totalPrice.toLocaleString()}</span>
                  </div>
                </div>

                <button
                  onClick={handleCheckout}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 rounded-lg font-bold text-lg hover:shadow-lg transition-all transform hover:scale-105"
                >
                  Proceed to Checkout
                </button>

                <Link 
                  to="/"
                  className="block text-center mt-4 text-blue-600 hover:text-blue-800 font-semibold"
                >
                  Continue Shopping →
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Cart;
