// src/pages/OrderConfirmation.js
import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { getProductImage, getCategoryFallbackImage } from '../utils/imageUtils';
import {
  getDynamicOrderStatus,
  getPaymentMethodIcon,
  getPaymentMethodLabel,
  getPaymentStatus,
} from '../utils/orderUtils';
import './OrderConfirmation.css';

const OrderConfirmation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [order, setOrder] = useState(location.state?.order || null);

  useEffect(() => {
    // If no order in state, try to get from localStorage (latest order)
    if (!order) {
      const orders = JSON.parse(localStorage.getItem('orders') || '[]');
      if (orders.length > 0) {
        setOrder(orders[orders.length - 1]);
      }
    }
  }, [order]);

  if (!order) {
    return (
      <div className="order-confirmation-container">
        <div className="order-not-found">
          <h2>Order not found</h2>
          <button onClick={() => navigate('/')} className="btn-primary">
            Go to Home
          </button>
        </div>
      </div>
    );
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const orderStatus = getDynamicOrderStatus(order);
  const paymentStatus = getPaymentStatus(order);

  return (
    <div className="order-confirmation-container">
      <div className="confirmation-content">
        {/* Success Animation */}
        <div className="success-animation">
          <div className="success-icon">✓</div>
        </div>

        <h1 className="confirmation-title">
          {paymentStatus === 'Paid'
            ? '🎉 Payment Successful!'
            : paymentStatus === 'Failed'
            ? '⚠️ Payment Failed'
            : '⌛ Payment Pending'}
        </h1>
        <h2 className="confirmation-subtitle">
          {orderStatus === 'Delivered'
            ? 'Order Delivered'
            : 'Order Placed Successfully'}
        </h2>

        <div className="order-details-card">
          <div className="order-header">
            <div>
              <p className="order-label">Order ID</p>
              <p className="order-value">{order.id}</p>
            </div>
            <div className="order-status-badge">
              <span className="status-dot"></span>
              {orderStatus}
            </div>
          </div>

          <div className="order-info-grid">
            <div className="order-info-item">
              <p className="info-label">Order Date</p>
              <p className="info-value">{formatDate(order.orderDate)}</p>
            </div>
            <div className="order-info-item">
              <p className="info-label">Expected Delivery</p>
              <p className="info-value">{formatDate(order.deliveryDate)}</p>
            </div>
            <div className="order-info-item">
              <p className="info-label">Payment Method</p>
              <p className="info-value">
                <span className="payment-method-badge">
                  {getPaymentMethodIcon(order.paymentMethod)}{" "}
                  {getPaymentMethodLabel(order.paymentMethod)}
                </span>
              </p>
            </div>
            <div className="order-info-item">
              <p className="info-label">Payment Status</p>
              <p className="info-value">
                <span
                  className={`payment-status-badge ${
                    paymentStatus === 'Paid'
                      ? 'payment-status-paid'
                      : paymentStatus === 'Failed'
                      ? 'payment-status-failed'
                      : 'payment-status-pending'
                  }`}
                >
                  {paymentStatus}
                </span>
              </p>
            </div>
            <div className="order-info-item">
              <p className="info-label">Transaction ID</p>
              <p className="info-value">{order.transactionId}</p>
            </div>
          </div>

          {/* Delivery Address */}
          {order.address && (
            <div className="delivery-address-section">
              <h3 className="section-heading">Delivery Address</h3>
              <div className="address-box">
                <p className="address-name">{order.address.fullName}</p>
                <p className="address-phone">{order.address.phone}</p>
                <p className="address-text">
                  {order.address.address}, {order.address.city}, {order.address.state} - {order.address.pincode}
                </p>
              </div>
            </div>
          )}

          {/* Order Items */}
          <div className="order-items-section">
            <h3 className="section-heading">Order Items</h3>
            <div className="order-items-list">
              {order.items?.map((item) => (
                <div key={item.id} className="order-item">
                  <img
                    src={getProductImage(item)}
                    alt={item.name}
                    onError={(e) => {
                      e.target.src = getCategoryFallbackImage(item);
                    }}
                    className="order-item-image"
                  />
                  <div className="order-item-details">
                    <h4>{item.name}</h4>
                    <p className="order-item-category">{item.category}</p>
                    <p className="order-item-price">₹{item.price?.toLocaleString()}</p>
                  </div>
                  <div className="order-item-quantity">
                    Qty: {item.quantity || 1}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Price Summary */}
          <div className="price-summary-section">
            <div className="price-row">
              <span>Subtotal:</span>
              <span>₹{order.subtotal?.toLocaleString()}</span>
            </div>
            <div className="price-row">
              <span>Delivery Charge:</span>
              <span>{order.deliveryCharge === 0 ? 'Free' : `₹${order.deliveryCharge}`}</span>
            </div>
            <div className="price-row total-row">
              <span>Total Paid:</span>
              <span>₹{order.total?.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="confirmation-actions">
          <button onClick={() => navigate('/dashboard/orders')} className="btn-secondary">
            View All Orders
          </button>
          <button onClick={() => navigate('/')} className="btn-primary">
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;

