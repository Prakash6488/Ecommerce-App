// src/pages/Home.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import products from '../data/products';
import ProductCard from '../components/ProductCard';

const Home = () => {
  const [searchTerm, setSearchTerm] = useState('');

  // Get featured categories and products
  const categories = [...new Set(products.map(p => p.category))];
  const featuredProducts = products.filter(p => p.rating >= 4.3).slice(0, 8);
  const dealsProducts = products.filter(p => p.discount >= 30).slice(0, 6);
  const newArrivals = products.slice(-8);

  const categoryIcons = {
    'Fashion': '👕',
    'Electronics': '⚡',
    'Furniture': '🛋️',
    'Grocery': '🛒',
    'Sports': '🏃',
    'Books': '📚',
    'Beauty': '💄',
    'Toys': '🎮',
    'Home & Kitchen': '🍳',
    'Accessories': '🔌'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50">
      {/* Modern Hero Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 text-white">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white opacity-5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white opacity-5 rounded-full blur-3xl"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold mb-6 tracking-tight">
              Welcome to <span className="bg-gradient-to-r from-yellow-300 to-pink-300 bg-clip-text text-transparent">Ecommerce</span>
            </h1>
            <p className="text-xl md:text-2xl mb-10 text-gray-100 max-w-2xl mx-auto">
              Discover amazing deals on electronics, fashion, and more! Shop the latest trends at unbeatable prices.
            </p>
            
            {/* Enhanced Search Bar */}
            <div className="max-w-3xl mx-auto">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    placeholder="Search for products, brands and more..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full px-6 py-4 text-lg rounded-xl focus:outline-none focus:ring-4 focus:ring-yellow-300 text-gray-900 shadow-lg"
                  />
                  <span className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400">🔍</span>
                </div>
                <button className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-8 py-4 rounded-xl font-semibold hover:from-yellow-500 hover:to-orange-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
                  Search
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Modern Category Grid */}
        <div className="mb-16">
          <div className="text-center mb-10">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-3">Shop by Category</h2>
            <p className="text-gray-600 text-lg">Browse our wide range of categories</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
            {categories.slice(0, 10).map((category) => (
              <Link
                key={category}
                to={`/category/${encodeURIComponent(category)}`}
                className="group bg-white rounded-2xl p-6 text-center hover:shadow-2xl transition-all duration-300 border border-gray-100 hover:border-indigo-300 hover:-translate-y-2 transform"
              >
                <div className="text-5xl mb-3 transform group-hover:scale-110 transition-transform duration-300">
                  {categoryIcons[category] || '🛍️'}
                </div>
                <div className="text-sm font-semibold text-gray-700 group-hover:text-indigo-600 transition-colors">
                  {category}
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Modern Flash Sale Banner */}
        <div className="relative mb-16 overflow-hidden rounded-3xl bg-gradient-to-r from-red-500 via-pink-500 to-orange-500 text-white shadow-2xl">
          <div className="absolute inset-0 bg-black opacity-10"></div>
          <div className="relative p-8 md:p-12 text-center">
            <div className="inline-block mb-4 px-4 py-2 bg-white bg-opacity-20 rounded-full backdrop-blur-sm">
              <span className="text-2xl animate-pulse">⚡</span>
            </div>
            <h3 className="text-3xl md:text-4xl font-bold mb-3">FLASH SALE</h3>
            <p className="text-xl md:text-2xl mb-6 text-gray-100">Up to 70% OFF on selected items - Limited time offer!</p>
            <Link 
              to="/catalog?sort=discount" 
              className="inline-block bg-white text-red-600 px-8 py-3 rounded-xl font-bold hover:bg-gray-100 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Shop Now →
            </Link>
          </div>
        </div>

        {/* Featured Products Section */}
        <div className="mb-16">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">⭐ Featured Products</h2>
              <p className="text-gray-600 text-lg">Handpicked just for you</p>
            </div>
            <Link 
              to="/catalog" 
              className="mt-4 sm:mt-0 text-indigo-600 hover:text-indigo-800 font-semibold text-lg flex items-center gap-2 group"
            >
              View All 
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {featuredProducts.map((product) => (
              <div key={product.id} className="transform hover:scale-105 transition-transform duration-300">
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        </div>

        {/* Best Deals Section */}
        <div className="mb-16">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">🔥 Best Deals</h2>
              <p className="text-gray-600 text-lg">Don't miss out on these amazing offers</p>
            </div>
            <Link 
              to="/catalog?sort=discount" 
              className="mt-4 sm:mt-0 text-indigo-600 hover:text-indigo-800 font-semibold text-lg flex items-center gap-2 group"
            >
              View All 
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {dealsProducts.map((product) => (
              <div key={product.id} className="transform hover:scale-105 transition-transform duration-300">
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        </div>

        {/* New Arrivals Section */}
        <div className="mb-16">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">✨ New Arrivals</h2>
              <p className="text-gray-600 text-lg">Check out our latest products</p>
            </div>
            <Link 
              to="/catalog?sort=newest" 
              className="mt-4 sm:mt-0 text-indigo-600 hover:text-indigo-800 font-semibold text-lg flex items-center gap-2 group"
            >
              View All 
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {newArrivals.map((product) => (
              <div key={product.id} className="transform hover:scale-105 transition-transform duration-300">
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        </div>

        {/* Why Choose Us Section */}
        <div className="bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 md:p-12 mb-16 shadow-xl border border-gray-100">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-12 text-center">Why Choose Ecommerce?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            <div className="text-center group">
              <div className="inline-block p-6 bg-gradient-to-br from-blue-100 to-blue-200 rounded-3xl mb-4 group-hover:scale-110 transition-transform duration-300">
                <div className="text-5xl">🚚</div>
              </div>
              <h3 className="text-2xl font-bold mb-3 text-gray-900">Free Delivery</h3>
              <p className="text-gray-600 text-lg">Free delivery on orders above ₹500</p>
            </div>
            <div className="text-center group">
              <div className="inline-block p-6 bg-gradient-to-br from-green-100 to-green-200 rounded-3xl mb-4 group-hover:scale-110 transition-transform duration-300">
                <div className="text-5xl">🔄</div>
              </div>
              <h3 className="text-2xl font-bold mb-3 text-gray-900">Easy Returns</h3>
              <p className="text-gray-600 text-lg">30-day return policy on all products</p>
            </div>
            <div className="text-center group">
              <div className="inline-block p-6 bg-gradient-to-br from-purple-100 to-purple-200 rounded-3xl mb-4 group-hover:scale-110 transition-transform duration-300">
                <div className="text-5xl">💳</div>
              </div>
              <h3 className="text-2xl font-bold mb-3 text-gray-900">Secure Payment</h3>
              <p className="text-gray-600 text-lg">100% secure payment options</p>
            </div>
          </div>
        </div>

        {/* Modern Newsletter Signup */}
        <div className="relative overflow-hidden bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 text-white rounded-3xl p-8 md:p-12 text-center shadow-2xl">
          <div className="absolute inset-0 bg-black opacity-10"></div>
          <div className="relative z-10">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Stay Updated!</h2>
            <p className="text-xl md:text-2xl mb-8 text-gray-100">Subscribe to our newsletter for exclusive deals and offers</p>
            <div className="max-w-md mx-auto flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-6 py-4 rounded-xl text-gray-900 focus:outline-none focus:ring-4 focus:ring-yellow-300 shadow-lg text-lg"
              />
              <button className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-8 py-4 rounded-xl font-bold hover:from-yellow-500 hover:to-orange-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
