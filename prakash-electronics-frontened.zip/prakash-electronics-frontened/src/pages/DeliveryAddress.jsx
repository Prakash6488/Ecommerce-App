// src/pages/DeliveryAddress.jsx
import React, { useState } from "react";
import "./DeliveryAddress.css";

const DeliveryAddress = () => {
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
  });

  const [orderPlaced, setOrderPlaced] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setOrderPlaced(true);
  };

  return (
    <div className="delivery-container">
      {!orderPlaced ? (
        <>
          <h2>Delivery Address</h2>
          <form onSubmit={handleSubmit}>
            <input name="fullName" placeholder="Full Name" onChange={handleChange} required />
            <input name="phone" placeholder="Phone Number" onChange={handleChange} required />
            <textarea name="address" placeholder="Full Address" onChange={handleChange} required />
            <input name="city" placeholder="City" onChange={handleChange} required />
            <input name="state" placeholder="State" onChange={handleChange} required />
            <input name="pincode" placeholder="Pincode" onChange={handleChange} required />
            <button type="submit">Place Order</button>
          </form>
        </>
      ) : (
        <div className="order-confirmed">
          <h2>🎉 Order Confirmed!</h2>
          <p>Thank you for shopping with us.</p>
        </div>
      )}
    </div>
  );
};

export default DeliveryAddress;
