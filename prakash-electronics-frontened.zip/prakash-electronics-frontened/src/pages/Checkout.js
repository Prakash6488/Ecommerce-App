// src/pages/Checkout.js
import React, { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';
import './Checkout.css';
import { getProductImage, getCategoryFallbackImage } from '../utils/imageUtils';

const Checkout = () => {
  const { state, dispatch } = useCart();
  const { cart, buyNowItem } = state;
  const navigate = useNavigate();

  // Use buyNowItem if available, otherwise use cart
  const itemsToCheckout = buyNowItem ? [buyNowItem] : cart;

  const [step, setStep] = useState("cart"); // "cart" | "address" | "payment" | "processing"
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [address, setAddress] = useState({
    fullName: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
  });

  // Clear buyNowItem when component unmounts or after order
  useEffect(() => {
    return () => {
      if (buyNowItem) {
        dispatch({ type: 'CLEAR_BUY_NOW' });
      }
    };
  }, [buyNowItem, dispatch]);

  // Calculate totals
  const subtotal = itemsToCheckout.reduce((sum, item) => sum + (item.price || 0), 0);
  const deliveryCharge = subtotal > 500 ? 0 : 50;
  const total = subtotal + deliveryCharge;

  const handleChange = (e) => {
    setAddress({ ...address, [e.target.name]: e.target.value });
  };

  const handleAddressSubmit = (e) => {
    e.preventDefault();
    setStep("payment");
  };

  const handlePaymentMethodSelect = (method) => {
    setSelectedPaymentMethod(method);
  };

  const handlePayNow = async () => {
    if (!selectedPaymentMethod) {
      alert('Please select a payment method');
      return;
    }

    setIsProcessing(true);
    setStep("processing");

    // Simulate payment processing delay (2-3 seconds)
    const delay = Math.random() * 1000 + 2000; // 2000-3000ms
    await new Promise(resolve => setTimeout(resolve, delay));

    // Show success alert
    alert('Payment Successful ✅');

    // Create order object
    const orderId = `ORD-${Date.now()}`;
    const orderDate = new Date().toISOString();
    const deliveryDate = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(); // +3 days

    const order = {
      id: orderId,
      orderDate,
      deliveryDate,
      paymentMethod: selectedPaymentMethod,
      status: 'confirmed',
      address: { ...address },
      items: itemsToCheckout.map(item => ({
        id: item.id,
        name: item.name,
        price: item.price,
        image: item.image,
        category: item.category,
        quantity: 1
      })),
      subtotal,
      deliveryCharge,
      total,
      paymentStatus: 'paid',
      transactionId: `TXN-${Date.now()}`
    };

    // Save order to localStorage
    const existingOrders = JSON.parse(localStorage.getItem('orders') || '[]');
    existingOrders.push(order);
    localStorage.setItem('orders', JSON.stringify(existingOrders));

    // Clear cart and buyNowItem
    dispatch({ type: 'CLEAR_CART' });
    dispatch({ type: 'CLEAR_BUY_NOW' });

    // Navigate to order confirmation page with order details
    navigate('/order-confirmation', { state: { order } });
  };

  return (
    <div className="checkout-container">
      <h2 className="checkout-title">🛒 Checkout</h2>

      {itemsToCheckout.length === 0 && step !== "processing" ? (
        <div className="empty-cart">
          <p>Your cart is empty.</p>
          <button onClick={() => navigate('/')} className="btn-primary">Continue Shopping</button>
        </div>
      ) : step === "cart" ? (
        <>
          <div className="cart-items">
            {itemsToCheckout.map((item) => (
              <div key={item.id} className="cart-item">
                <img
                  src={getProductImage(item)}
                  alt={item.name}
                  onError={(e) => {
                    e.target.src = getCategoryFallbackImage(item);
                  }}
                />
                <div className="cart-item-details">
                  <h3>{item.name}</h3>
                  <p className="cart-item-price">₹{item.price?.toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="total-section">
            <div className="price-breakdown">
              <div className="price-row">
                <span>Subtotal:</span>
                <span>₹{subtotal.toLocaleString()}</span>
              </div>
              <div className="price-row">
                <span>Delivery:</span>
                <span>{deliveryCharge === 0 ? 'Free' : `₹${deliveryCharge}`}</span>
              </div>
              <div className="price-row total-row">
                <span>Total:</span>
                <span>₹{total.toLocaleString()}</span>
              </div>
            </div>
            <button onClick={() => setStep("address")} className="btn-primary">
              Proceed to Delivery Address
            </button>
          </div>
        </>
      ) : step === "address" ? (
        <>
          <h3 className="section-title">Enter Delivery Address</h3>
          <form onSubmit={handleAddressSubmit} className="address-form">
            <input 
              name="fullName" 
              placeholder="Full Name" 
              value={address.fullName}
              onChange={handleChange} 
              required 
            />
            <input 
              name="phone" 
              type="tel"
              placeholder="Phone Number" 
              value={address.phone}
              onChange={handleChange} 
              required 
            />
            <textarea 
              name="address" 
              placeholder="Full Address" 
              value={address.address}
              onChange={handleChange} 
              required 
              rows="3"
            />
            <div className="form-row">
              <input 
                name="city" 
                placeholder="City" 
                value={address.city}
                onChange={handleChange} 
                required 
              />
              <input 
                name="state" 
                placeholder="State" 
                value={address.state}
                onChange={handleChange} 
                required 
              />
            </div>
            <input 
              name="pincode" 
              type="text"
              placeholder="Pincode" 
              value={address.pincode}
              onChange={handleChange} 
              required 
            />
            <div className="form-actions">
              <button type="button" onClick={() => setStep("cart")} className="btn-secondary">
                Back
              </button>
              <button type="submit" className="btn-primary">
                Continue to Payment
              </button>
            </div>
          </form>
        </>
      ) : step === "payment" ? (
        <>
          <h3 className="section-title">💳 Select Payment Method</h3>
          
          <div className="payment-summary">
            <div className="summary-item">
              <span>Subtotal:</span>
              <span>₹{subtotal.toLocaleString()}</span>
            </div>
            <div className="summary-item">
              <span>Delivery:</span>
              <span>{deliveryCharge === 0 ? 'Free' : `₹${deliveryCharge}`}</span>
            </div>
            <div className="summary-item total-item">
              <span>Total Payable:</span>
              <span>₹{total.toLocaleString()}</span>
            </div>
          </div>

          <div className="payment-methods">
            <div 
              className={`payment-method ${selectedPaymentMethod === 'card' ? 'selected' : ''}`}
              onClick={() => handlePaymentMethodSelect('card')}
            >
              <div className="payment-method-icon">💳</div>
              <div className="payment-method-details">
                <h4>Credit/Debit Card</h4>
                <p>Pay using your card</p>
              </div>
              <div className="payment-method-radio">
                {selectedPaymentMethod === 'card' && <span className="radio-dot"></span>}
              </div>
            </div>

            <div 
              className={`payment-method ${selectedPaymentMethod === 'upi' ? 'selected' : ''}`}
              onClick={() => handlePaymentMethodSelect('upi')}
            >
              <div className="payment-method-icon">📱</div>
              <div className="payment-method-details">
                <h4>UPI</h4>
                <p>Pay using UPI apps</p>
              </div>
              <div className="payment-method-radio">
                {selectedPaymentMethod === 'upi' && <span className="radio-dot"></span>}
              </div>
            </div>

            <div 
              className={`payment-method ${selectedPaymentMethod === 'netbanking' ? 'selected' : ''}`}
              onClick={() => handlePaymentMethodSelect('netbanking')}
            >
              <div className="payment-method-icon">🏦</div>
              <div className="payment-method-details">
                <h4>NetBanking</h4>
                <p>Pay using your bank account</p>
              </div>
              <div className="payment-method-radio">
                {selectedPaymentMethod === 'netbanking' && <span className="radio-dot"></span>}
              </div>
            </div>

            <div 
              className={`payment-method ${selectedPaymentMethod === 'cod' ? 'selected' : ''}`}
              onClick={() => handlePaymentMethodSelect('cod')}
            >
              <div className="payment-method-icon">💰</div>
              <div className="payment-method-details">
                <h4>Cash on Delivery (COD)</h4>
                <p>Pay when you receive</p>
              </div>
              <div className="payment-method-radio">
                {selectedPaymentMethod === 'cod' && <span className="radio-dot"></span>}
              </div>
            </div>

            <div 
              className={`payment-method ${selectedPaymentMethod === 'razorpay' ? 'selected' : ''}`}
              onClick={() => handlePaymentMethodSelect('razorpay')}
            >
              <div className="payment-method-icon">🔐</div>
              <div className="payment-method-details">
                <h4>Razorpay</h4>
                <p>Secure payment gateway</p>
              </div>
              <div className="payment-method-radio">
                {selectedPaymentMethod === 'razorpay' && <span className="radio-dot"></span>}
              </div>
            </div>
          </div>

          <div className="payment-actions">
            <button onClick={() => setStep("address")} className="btn-secondary">
              Back
            </button>
            <button 
              onClick={handlePayNow} 
              className="btn-pay-now"
              disabled={!selectedPaymentMethod}
            >
              Pay Now ₹{total.toLocaleString()}
            </button>
          </div>
        </>
      ) : step === "processing" ? (
        <div className="processing-payment">
          <div className="spinner"></div>
          <h3>Processing Payment...</h3>
          <p>Please wait while we process your payment</p>
        </div>
      ) : null}
    </div>
  );
};

export default Checkout;
