// src/pages/User/MyProfile.js
import React from "react";

const MyProfile = () => {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">My Profile</h2>
      <p>👤 Full Name: Prakash Kumar</p>
      <p>📧 Email: prakash@example.com</p>
      {/* Add more fields here */}
    </div>
  );
};

export default MyProfile;
