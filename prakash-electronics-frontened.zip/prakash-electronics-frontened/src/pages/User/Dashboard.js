// src/pages/User/Dashboard.js
import React from "react";
import { Link, Outlet } from "react-router-dom";

const Dashboard = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">👤 User Dashboard</h2>

      <div className="flex gap-6 mb-6">
        <Link to="profile" className="text-blue-600 hover:underline">My Profile</Link>
        <Link to="orders" className="text-blue-600 hover:underline">My Orders</Link>
        <Link to="edit" className="text-blue-600 hover:underline">Edit Profile</Link>
      </div>

      {/* ✅ Yeh jagah profile/orders/edit show hoga */}
      <Outlet />
    </div>
  );
};

export default Dashboard;
