// src/pages/User/EditProfile.js
import React, { useState, useEffect } from 'react';
import './EditProfile.css'; // Optional if you want custom styles

const EditProfile = () => {
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    gender: '',
    dob: '',
    country: '',
    state: '',
    profilePicture: ''
  });

  // Simulate loading existing user data (you can replace with API call)
  useEffect(() => {
    const userData = JSON.parse(localStorage.getItem('user')) || {};
    setForm(userData);
  }, []);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'profilePicture') {
      setForm({ ...form, [name]: files[0]?.name }); // Just simulating filename
    } else {
      setForm({ ...form, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    localStorage.setItem('user', JSON.stringify(form)); // Replace with PUT API
    alert('✅ Profile updated successfully!');
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold mb-4 text-center text-blue-700">✏️ Edit Profile</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="fullName" value={form.fullName} onChange={handleChange} className="input" placeholder="Full Name" required />
        <input name="email" type="email" value={form.email} onChange={handleChange} className="input" placeholder="Email" required />
        <input name="phone" value={form.phone} onChange={handleChange} className="input" placeholder="Phone Number" required />
        <input name="address" value={form.address} onChange={handleChange} className="input" placeholder="Address" />
        
        <select name="gender" value={form.gender} onChange={handleChange} className="input" required>
          <option value="">Select Gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>

        <input name="dob" type="date" value={form.dob} onChange={handleChange} className="input" />

        <input name="country" value={form.country} onChange={handleChange} className="input" placeholder="Country" />
        <input name="state" value={form.state} onChange={handleChange} className="input" placeholder="State" />

        <input name="profilePicture" type="file" onChange={handleChange} className="input" />

        <button type="submit" className="bg-blue-600 text-white w-full py-2 rounded hover:bg-blue-700">
          Update Profile
        </button>
      </form>
    </div>
  );
};

export default EditProfile;
