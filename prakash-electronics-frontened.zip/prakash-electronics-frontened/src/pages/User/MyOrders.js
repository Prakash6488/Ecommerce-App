// src/pages/User/MyOrders.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import products from "../../data/products";
import {
  getProductImage,
  getCategoryFallbackImage,
} from "../../utils/imageUtils";
import {
  ORDER_TIMELINE_STAGES,
  getDynamicOrderStatus,
  getTimelineStageIndex,
  getPaymentStatus,
  getPaymentMethodLabel,
} from "../../utils/orderUtils";

const MyOrders = () => {
  const [orders, setOrders] = useState([]);
  const userId = localStorage.getItem("userId") || localStorage.getItem("guestId");

  useEffect(() => {
    const token = localStorage.getItem('token');
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    // Try API only if it's a real userId (not guest)
    const isGuest = String(userId || '').startsWith('guest-');
    const tryApi = !isGuest && userId;
    
    const fetchLocal = () => {
      // Fallback to locally stored orders created during checkout
      const local = JSON.parse(localStorage.getItem('orders') || '[]');
      
      // Filter orders - new structure has items array, old structure has productId
      let mine = local;
      if (userId && !isGuest) {
        mine = local.filter(o => String(o.userId) === String(userId));
      }
      
      // Handle both old structure (single product per order) and new structure (items array)
      const enrichedOrders = mine.map(order => {
        // New structure with items array
        if (order.items && Array.isArray(order.items)) {
          return {
            ...order,
            items: order.items.map(item => {
              const prod = products.find(p => String(p.id) === String(item.id));
              return {
                ...item,
                product: prod || null
              };
            })
          };
        }
        // Old structure with single productId
        else {
          const prod = products.find(p => String(p.id) === String(order.productId));
          return {
            ...order,
            product: prod || null,
            items: [{
              id: order.productId,
              name: prod?.name || `Product #${order.productId}`,
              price: prod?.price || 0,
              quantity: order.quantity || 1,
              product: prod
            }]
          };
        }
      });
      
      setOrders(enrichedOrders);
    };

    if (tryApi) {
      axios.get(`http://localhost:8080/api/orders/user/${userId}`, { headers })
        .then(res => {
          const enriched = res.data.map(order => {
            const prod = products.find(p => String(p.id) === String(order.productId));
            return {
              ...order,
              product: prod || null,
              items: [{
                id: order.productId,
                name: prod?.name || `Product #${order.productId}`,
                price: prod?.price || 0,
                quantity: order.quantity || 1,
                product: prod
              }]
            };
          });
          setOrders(enriched);
        })
        .catch(fetchLocal);
    } else {
      fetchLocal();
    }
  }, [userId]);

  return (
    <div className="p-4 min-h-screen bg-gray-50">
      <h2 className="text-3xl font-bold mb-6">🛍️ My Orders</h2>
      {orders.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg mb-4">No orders yet.</p>
          <a href="/" className="text-blue-600 hover:underline">Start Shopping</a>
        </div>
      ) : (
        <div className="space-y-6">
          {orders.map(order => {
            const status = getDynamicOrderStatus(order);
            const stageIdx = getTimelineStageIndex(order);
            const paymentStatus = getPaymentStatus(order);
            const orderDate = order.orderDate ? new Date(order.orderDate) : null;
            const deliveryDate = order.deliveryDate ? new Date(order.deliveryDate) : null;

            return (
              <div key={order.id} className="bg-white border rounded-lg p-6 shadow-md">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="font-bold text-lg text-gray-900">Order #{order.id}</div>
                    <div className="text-sm text-gray-600 mt-1">
                      🕒 Ordered: {orderDate ? orderDate.toLocaleString() : '—'}
                    </div>
                    {deliveryDate && (
                      <div className="text-sm text-gray-600">
                        🚚 Est. Delivery: {deliveryDate.toLocaleDateString()}
                      </div>
                    )}
                    <div className="text-sm text-gray-600 mt-1">
                      💳 Payment: {getPaymentMethodLabel(order.paymentMethod)} •{" "}
                      <span
                        className={`font-semibold ${
                          paymentStatus === "Paid"
                            ? "text-green-700"
                            : paymentStatus === "Failed"
                            ? "text-red-700"
                            : "text-yellow-700"
                        }`}
                      >
                        {paymentStatus}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-xl text-gray-900">₹{order.total?.toLocaleString() || '—'}</div>
                    <div className={`inline-block px-3 py-1 rounded-full text-xs font-semibold mt-2 ${
                      status === 'Delivered' ? 'bg-green-100 text-green-800' :
                      status === 'Out for delivery' ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {status}
                    </div>
                  </div>
                </div>

                {/* Order Items */}
                {order.items && order.items.length > 0 && (
                  <div className="border-t pt-4 mt-4">
                    <h3 className="font-semibold mb-3 text-gray-700">Items:</h3>
                    <div className="space-y-3">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-4">
                          {item.product && (
                            <img
                              src={getProductImage(item.product)}
                              alt={item.name}
                              className="w-20 h-20 object-cover rounded"
                              onError={(e) => {
                                e.target.src = getCategoryFallbackImage(item.product);
                              }}
                            />
                          )}
                          <div className="flex-1">
                            <div className="font-semibold">{item.name || item.product?.name || `Product #${item.id}`}</div>
                            <div className="text-gray-600">₹{item.price?.toLocaleString() || '—'} • Qty: {item.quantity || 1}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Old structure - single product */}
                {(!order.items || order.items.length === 0) && order.product && (
                  <div className="flex items-center gap-4 border-t pt-4 mt-4">
                    <img
                      src={getProductImage(order.product)}
                      alt={order.product.name}
                      className="w-20 h-20 object-cover rounded"
                      onError={(e) => {
                        e.target.src = getCategoryFallbackImage(order.product);
                      }}
                    />
                    <div className="flex-1">
                      <div className="font-semibold">{order.product.name}</div>
                      <div className="text-gray-600">₹{order.product.price?.toLocaleString() || '—'} • Qty: {order.quantity || 1}</div>
                    </div>
                  </div>
                )}

                {/* Delivery Address */}
                {order.address && (
                  <div className="border-t pt-4 mt-4">
                    <h3 className="font-semibold mb-2 text-gray-700">Delivery Address:</h3>
                    <div className="text-sm text-gray-600">
                      <div>{order.address.fullName}</div>
                      <div>{order.address.phone}</div>
                      <div>{order.address.address}, {order.address.city}, {order.address.state} - {order.address.pincode}</div>
                    </div>
                  </div>
                )}

                {/* Status Progress */}
                <div className="mt-6 pt-4 border-t">
                  <div className="flex items-center overflow-x-auto">
                    {ORDER_TIMELINE_STAGES.map((label, i) => (
                      <div
                        key={label}
                        className="flex items-center flex-shrink-0"
                      >
                        <div
                          className={`w-3 h-3 rounded-full ${
                            i <= stageIdx ? "bg-green-600" : "bg-gray-300"
                          }`}
                        ></div>
                        <div
                          className={`mx-2 text-xs whitespace-nowrap ${
                            i <= stageIdx
                              ? "text-green-700 font-semibold"
                              : "text-gray-500"
                          }`}
                        >
                          {label}
                        </div>
                        {i < ORDER_TIMELINE_STAGES.length - 1 && (
                          <div
                            className={`w-10 h-0.5 ${
                              i < stageIdx ? "bg-green-600" : "bg-gray-300"
                            }`}
                          ></div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
      {String(userId || '').startsWith('guest-') && (
        <p className="mt-4 text-sm text-gray-600 text-center">Showing orders stored on this device for guest checkout.</p>
      )}
    </div>
  );
};

export default MyOrders;
